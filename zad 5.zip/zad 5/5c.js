var tablica=[-5, 0, 10, 20, 1500100900];

function viceMax(tablica){
    var max = Math.max.apply(null, tablica);
    tablica.splice(tablica.indexOf(max), 1);
    return Math.max.apply(null, tablica);
};

console.log(viceMax(tablica))
