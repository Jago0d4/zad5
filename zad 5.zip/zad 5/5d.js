var number = [9, 5, 12];

function checkNumber(number) {
  if (number[0] < Math.max.apply(null, number) && number[0] > Math.min.apply(null, number)) {
    return true;
  } else {
    return false;
  }
}

console.log(checkNumber(number))
