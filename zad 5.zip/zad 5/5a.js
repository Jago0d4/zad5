function silnia(n) {
   if ((n == 0) || (n == 1))
      return 1;
   else {
      var result = (n * silnia(n-1) );
      return result;
   }
}
console.log(silnia(4)); 
