var tablica=[-5, 0, 10, 20, 1500100900];

function wartoscMax (tablica){
   return Math.max.apply(null, tablica);
}

console.log(wartoscMax(tablica))
