var liczba = (Math.round(Math.random() * 10));
console.log(liczba)
function checkRandom(liczba) {
  if(liczba%2 == 0){
    console.log("Parzysta");
    }else{
    console.log("Nieparzysta");
    }
}

console.log(checkRandom(liczba))
